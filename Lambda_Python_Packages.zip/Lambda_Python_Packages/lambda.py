
import mysql.connector
def lambda_handler(event, context):
    try:
        db_host = '34.86.43.39'
        db_user = 'hamletsantana'
        db_password = 'Hamlet260400'
        db_name = 'dentist-appointments'
        
        connection = mysql.connector.connect(
        user=db_user,
        password=db_password,
        host=db_host,
        database=db_name
        )
        return {
            'statusCode': 200,
            'body': 'Connected to database successfully'
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': f'Error: {str(e)}'
        }